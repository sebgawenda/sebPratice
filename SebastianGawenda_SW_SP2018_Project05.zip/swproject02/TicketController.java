/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swproject02;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;


/**
 *
 * @author utrgv
 */
public final class TicketController {
    TicketModel ticketModel;
    TicketView ticketView;
    
   
    
    
    
    public TicketController(TicketModel ticketModel, TicketView ticketView)
    {
        this.ticketView = ticketView;
        this.ticketModel = ticketModel;
        this.attachHandlers();
        System.out.println("2");
    
    }
    
    public void attachHandlers()
    {
        System.out.println("4");
        
        ArrayList<ParkedCar> ticketList = new ArrayList<>();
        
        /*
        ticketView.getClearAdd().setOnAction(e -> { 
            ticketView.clearAllAdd();
            });
        
        */
        
        ParkedCar ticket = new ParkedCar();
        
        
        
        ticketView.getAddTicket().setOnAction((ActionEvent e) -> {
            
            System.out.println("3");
            
            
            //String license = ticketView.getLicenseTF().getText();
            ticket.setLicense(ticketView.getLicenseTF().getText());
            
            //String state = ticketView.getStateTF().getText();
            ticket.setState(ticketView.getStateTF().getText());
            
            //String permitNo = ticketView.getPermitTF().getText();
            ticket.setPermitNo(ticketView.getPermitTF().getText());
            
            //String make = ticketView.getMakeTF().getText();
            ticket.setMake(ticketView.getMakeTF().getText());
            
            String model = ticketView.getModelTF().getText();
            ticket.setModel(ticketView.getModelTF().getText());
            
            //String color = ticketView.getColorTF().getText();
            ticket.setColor(ticketView.getColorTF().getText());
            
            //String date = ticketView.getDateTF().getText();
            ticket.setDate(ticketView.getDateTF().getText());
            
            //String location = ticketView.getLocationTF().getText();
            ticket.setLocation(ticketView.getLocationTF().getText());
            
            //String time = ticketView.getTimeTF().getText();
            ticket.setTime(ticketView.getTimeTF().getText());
            
            //String issue = ticketView.getIssueTF().getText();
            ticket.setIssuedBy(ticketView.getIssueTF().getText());
            
            //String offense = "";
            //String list = "";
            
            if(ticketView.getToggleOffense().equals(ticketView.getNoPermitToggle()))
            {
                //offense = "No Permit";
                ticket.setOffense("No Permit");
            }
            else if(ticketView.getToggleOffense().equals(ticketView.getWrongSpotToggle()))
            {
                //offense = "Wrong Spot";
                ticket.setOffense("Wrong Spot");
            }
            else if(ticketView.getToggleOffense().equals(ticketView.getBadParkingToggle()))
            {
                //offense = "Bad Parking";
                ticket.setOffense("Bad Parking");
            }
            else
            {
                //offense = "Please see police station";
                ticket.setOffense("Please see police station");
            }
            
            /*
            list += "License: " + license + ", State: " + state
            + ", Permit No.: " + permitNo + ", Make: " + make + ", Model: "
            + model + ", Color: " + color + ", Date: " + date + ", Location: "
            + location + ", Time: " + time + ", Issued By: " + issue
            + "Offense" + offense;
            */
            
            
            
            System.out.println(ticket.toString());
            ticketList.add(ticket);
            ticketView.clearAllAdd();
            ticketModel.storeTickets(ticket);
            
            
        });

    ticketView.getPrintAll().setOnAction(e ->{
        for(int i = 0; i < ticketList.size(); i++)
        {
            System.out.println("Ticket " +(i+1));
            try {
                ticketModel.readTickets();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TicketController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(TicketController.class.getName()).log(Level.SEVERE, null, ex);
            }
            ticketView.getPrintField().setText("Ticket " +(i+1) + ticketModel.getCurrentTickets().toString());
            //System.out.println(ticketModel.ticketList.get(i).toString());
            //System.out.println("\n");
        }
    });
    
    
    
    }

   
   
    
}
