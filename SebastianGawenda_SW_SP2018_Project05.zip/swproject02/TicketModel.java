/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swproject02;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.scene.layout.GridPane;


/**
 *
 * @author admin
 */
public class TicketModel extends GridPane {
    ArrayList<ParkedCar> ticketList = new ArrayList<>();
    ParkedCar ticket = new ParkedCar();
    DataOutputStream out;
    DataInputStream in;
    
    
    
    
    
    public TicketModel(){
        try{
            out = new DataOutputStream(new BufferedOutputStream(
            new FileOutputStream("TicketList.txt")));
        }
        catch (Exception e){}
        
        try{
            in = new DataInputStream(new BufferedInputStream(
            new FileInputStream("TicketList.txt")));
            
    }catch (Exception e){}
    
    }
    
    
    
    
    public void setCurrentTicket(ParkedCar ticket)
    {
        this.ticket = ticket;
        ticketList.add(ticket);
    }
    
    public ParkedCar getCurrentTicket()
    {
        return ticket;
    }
    
    public void storeTickets(ParkedCar ticket)
    {
        
        
        /* list += "License: " + license + ", State: " + state
            + ", Permit No.: " + permitNo + ", Make: " + make + ", Model: "
            + model + ", Color: " + color + ", Date: " + date + ", Location: "
            + location + ", Time: " + time + ", Issued By: " + issue
            + "Offense" + offense;

*/
        try{
            out.writeUTF(ticket.getLicense() + " ");
            out.writeUTF(ticket.getState()+ " ");
            out.writeUTF(ticket.getPermitNo()+ " s");
            out.writeUTF(ticket.getMake()+ " ");
            out.writeUTF(ticket.getModel()+ " ");
            out.writeUTF(ticket.getColor()+ " ");
            out.writeUTF(ticket.getDate()+ " ");
            out.writeUTF(ticket.getLocation()+ " ");
            out.writeUTF(ticket.getTime()+ " ");
            out.writeUTF(ticket.getIssuedBy()+ " ");
            out.writeUTF(ticket.getOffense());
            out.writeUTF("\n");
            out.close();
        
        }catch (Exception e){}
        
    
    }
    
    public void readTickets() throws FileNotFoundException, IOException
    {
        int i = 0;
        while(in.available()>0){
            String k = in.readUTF();
            switch(i)
            {
                case 0: ticket.setLicense(k);
                case 1: ticket.setState(k);
                case 2: ticket.setPermitNo(k);
                case 3: ticket.setMake(k);
                case 4: ticket.setModel(k);
                case 5: ticket.setColor(k);
                case 6: ticket.setDate(k);
                case 7: ticket.setLocation(k);
                case 9: ticket.setTime(k);
                case 10: ticket.setIssuedBy(k);
                case 11: ticket.setOffense(k);
               
            }
            
            System.out.println(k + "");
            i++;
            if(i == 12)
            {i = 0;}
        }
      ticketList.add(ticket);
        
        
       
    }
    
    
    
    public ArrayList<ParkedCar> getCurrentTickets()
    {
        
        
        return ticketList;
    }
    
   
}
